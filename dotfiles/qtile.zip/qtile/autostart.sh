#!/bin/bash

volumeicon &

# Audio
pulseaudio -k &
sleep 1 &
pulseaudio -D &

# Monitor
xset -dpms &
xset s off &

# MX Master Mouse
echo sparky | sudo -S solaar -w hide &
